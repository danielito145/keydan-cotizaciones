<?php
// iniciar_produccion.php
require_once 'config/db.php';
session_start();

// Verificar si se proporcionó un ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: ordenes.php?error=ID de orden no proporcionado");
    exit;
}

$id_orden = $_GET['id'];
$id_usuario = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 1; // Obtener ID del usuario logueado o usar valor por defecto
$fecha_inicio = date('Y-m-d H:i:s');

// Si se envió el formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['detalles_produccion'])) {
    $detalles_produccion = $_POST['detalles_produccion'];
    $fecha_estimada = isset($_POST['fecha_estimada_completado']) ? $_POST['fecha_estimada_completado'] : null;
    $responsable_produccion = isset($_POST['responsable_produccion']) ? $_POST['responsable_produccion'] : null;
    
    try {
        // Iniciar transacción
        $conn->beginTransaction();
        
        // Verificar si la orden existe y obtener sus datos
        $stmt = $conn->prepare("SELECT * FROM ordenes_venta WHERE id_orden = :id");
        $stmt->bindParam(':id', $id_orden);
        $stmt->execute();
        
        if ($stmt->rowCount() === 0) {
            throw new Exception("Orden no encontrada");
        }
        
        $orden = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Verificar que la orden esté en estado 'pendiente'
        if ($orden['estado'] !== 'pendiente') {
            throw new Exception("Solo se pueden iniciar producción en órdenes en estado 'pendiente'");
        }
        
        // Actualizar el estado de la orden a 'en_produccion'
        $stmt = $conn->prepare("UPDATE ordenes_venta SET 
                              estado = 'en_produccion', 
                              fecha_inicio_produccion = :fecha_inicio,
                              fecha_estimada_completado = :fecha_estimada,
                              responsable_produccion = :responsable_produccion,
                              detalles_produccion = :detalles_produccion
                              WHERE id_orden = :id");
        
        $stmt->bindParam(':fecha_inicio', $fecha_inicio);
        $stmt->bindParam(':fecha_estimada', $fecha_estimada);
        $stmt->bindParam(':responsable_produccion', $responsable_produccion);
        $stmt->bindParam(':detalles_produccion', $detalles_produccion);
        $stmt->bindParam(':id', $id_orden);
        $stmt->execute();
        
        // Registrar en historial de cambios
        $stmt = $conn->prepare("INSERT INTO historial_orden 
                                (id_orden, id_usuario, fecha_cambio, estado_anterior, estado_nuevo, comentario) 
                                VALUES (:id_orden, :id_usuario, :fecha_cambio, :estado_anterior, :estado_nuevo, :comentario)");
        
        $estado_anterior = $orden['estado'];
        $estado_nuevo = 'en_produccion';
        $comentario = "Inicio de producción: " . $detalles_produccion;
        
        $stmt->bindParam(':id_orden', $id_orden);
        $stmt->bindParam(':id_usuario', $id_usuario);
        $stmt->bindParam(':fecha_cambio', $fecha_inicio);
        $stmt->bindParam(':estado_anterior', $estado_anterior);
        $stmt->bindParam(':estado_nuevo', $estado_nuevo);
        $stmt->bindParam(':comentario', $comentario);
        $stmt->execute();
        
        // Confirmar transacción
        $conn->commit();
        
        // Redirigir a la página de ver orden con mensaje de éxito
        header("Location: ver_orden.php?id=" . $id_orden . "&success=1&message=" . urlencode("La orden ha iniciado producción correctamente"));
        exit;
        
    } catch(Exception $e) {
        // Deshacer transacción en caso de error
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        
        // Redirigir con mensaje de error
        header("Location: ver_orden.php?id=" . $id_orden . "&error=" . urlencode("Error al iniciar producción: " . $e->getMessage()));
        exit;
    }
} else {
    // Mostrar formulario
    require_once 'includes/header.php';
    
    // Obtener datos de la orden
    $stmt = $conn->prepare("SELECT o.*, cl.razon_social as cliente 
                           FROM ordenes_venta o 
                           JOIN clientes cl ON o.id_cliente = cl.id_cliente 
                           WHERE o.id_orden = :id");
    $stmt->bindParam(':id', $id_orden);
    $stmt->execute();
    $orden = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Obtener detalles de la orden
    $stmt = $conn->prepare("SELECT od.*, m.nombre as material 
                           FROM orden_detalles od 
                           JOIN materiales m ON od.id_material = m.id_material 
                           WHERE od.id_orden = :id");
    $stmt->bindParam(':id', $id_orden);
    $stmt->execute();
    $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener lista de responsables de producción
    $stmt = $conn->prepare("SELECT id_usuario, nombre, apellido FROM usuarios WHERE activo = 1 ORDER BY nombre");
    $stmt->execute();
    $responsables = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Verificar que exista la orden y esté en estado pendiente
    if (!$orden || $orden['estado'] !== 'pendiente') {
        header("Location: ordenes.php?error=" . urlencode("La orden no existe o no se puede iniciar producción"));
        exit;
    }
?>
    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-8">
                <h2><i class="fas fa-industry"></i> Iniciar Producción</h2>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="ordenes.php">Órdenes de Venta</a></li>
                        <li class="breadcrumb-item"><a href="ver_orden.php?id=<?php echo $id_orden; ?>">Detalle de Orden #<?php echo $orden['codigo']; ?></a></li>
                        <li class="breadcrumb-item active" aria-current="page">Iniciar Producción</li>
                    </ol>
                </nav>
            </div>
            <div class="col-md-4 text-right">
                <a href="ver_orden.php?id=<?php echo $id_orden; ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver
                </a>
            </div>
        </div>
        
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-industry mr-2"></i> Iniciar Producción de Orden</h5>
                    </div>
                    <div class="card-body">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle mr-2"></i>
                            Está a punto de iniciar la producción de la orden <strong><?php echo $orden['codigo']; ?></strong> 
                            para el cliente <strong><?php echo $orden['cliente']; ?></strong>.
                        </div>
                        
                        <form method="post" action="iniciar_produccion.php?id=<?php echo $id_orden; ?>">
                            <div class="form-group">
                                <label for="responsable_produccion">Responsable de Producción:</label>
                                <select class="form-control" id="responsable_produccion" name="responsable_produccion" required>
                                    <option value="">-- Seleccione un responsable --</option>
                                    <?php foreach($responsables as $responsable): ?>
                                        <option value="<?php echo $responsable['id_usuario']; ?>">
                                            <?php echo $responsable['nombre'] . ' ' . $responsable['apellido']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <small class="form-text text-muted">
                                    Seleccione la persona responsable de supervisar la producción de esta orden.
                                </small>
                            </div>
                            
                            <div class="form-group">
                                <label for="fecha_estimada_completado">Fecha Estimada de Completado:</label>
                                <input type="date" class="form-control" id="fecha_estimada_completado" name="fecha_estimada_completado" required
                                       min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>">
                                <small class="form-text text-muted">
                                    Ingrese la fecha estimada en que se completará la producción de esta orden.
                                </small>
                            </div>
                            
                            <div class="form-group">
                                <label for="detalles_produccion">Detalles de Producción:</label>
                                <textarea class="form-control" id="detalles_produccion" name="detalles_produccion" rows="4" required></textarea>
                                <small class="form-text text-muted">
                                    Ingrese detalles sobre el proceso de producción, instrucciones especiales o consideraciones a tener en cuenta.
                                </small>
                            </div>
                            
                            <div class="form-group">
                                <label>Verificación de Materiales:</label>
                                <div class="table-responsive">
                                    <table class="table table-bordered table-sm">
                                        <thead class="thead-light">
                                            <tr>
                                                <th>Material</th>
                                                <th>Descripción</th>
                                                <th>Cantidad</th>
                                                <th>Verificado</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach($detalles as $index => $detalle): ?>
                                                <tr>
                                                    <td><?php echo $detalle['material']; ?></td>
                                                    <td><?php echo $detalle['descripcion']; ?></td>
                                                    <td><?php echo number_format($detalle['cantidad']); ?></td>
                                                    <td>
                                                        <div class="custom-control custom-checkbox">
                                                            <input type="checkbox" class="custom-control-input material-check" 
                                                                   id="check_material_<?php echo $index; ?>" required>
                                                            <label class="custom-control-label" for="check_material_<?php echo $index; ?>">
                                                                Disponible
                                                            </label>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <label>Resumen:</label>
                                <div class="alert alert-light">
                                    <p><strong>Orden:</strong> <?php echo $orden['codigo']; ?></p>
                                    <p><strong>Cliente:</strong> <?php echo $orden['cliente']; ?></p>
                                    <p><strong>Fecha de Emisión:</strong> <?php echo date('d/m/Y', strtotime($orden['fecha_emision'])); ?></p>
                                    <p><strong>Total:</strong> S/ <?php echo number_format($orden['total'], 2); ?></p>
                                </div>
                            </div>
                            
                            <div class="text-right">
                                <a href="ver_orden.php?id=<?php echo $id_orden; ?>" class="btn btn-secondary">
                                    <i class="fas fa-times mr-1"></i> Cancelar
                                </a>
                                <button type="submit" class="btn btn-primary" id="btn-iniciar-produccion" disabled>
                                    <i class="fas fa-industry mr-1"></i> Iniciar Producción
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">Etapas de Producción</h5>
                    </div>
                    <div class="card-body">
                        <div class="timeline-steps">
                            <div class="timeline-step active">
                                <div class="timeline-step-marker">1</div>
                                <div class="timeline-step-content">
                                    <h6>Inicio de Producción</h6>
                                    <p class="text-muted small">Verificación de materiales y asignación de responsables</p>
                                </div>
                            </div>
                            <div class="timeline-step">
                                <div class="timeline-step-marker">2</div>
                                <div class="timeline-step-content">
                                    <h6>Proceso de Fabricación</h6>
                                    <p class="text-muted small">Corte, sellado, impresión y acabados</p>
                                </div>
                            </div>
                            <div class="timeline-step">
                                <div class="timeline-step-marker">3</div>
                                <div class="timeline-step-content">
                                    <h6>Control de Calidad</h6>
                                    <p class="text-muted small">Verificación de estándares y especificaciones</p>
                                </div>
                            </div>
                            <div class="timeline-step">
                                <div class="timeline-step-marker">4</div>
                                <div class="timeline-step-content">
                                    <h6>Completado</h6>
                                    <p class="text-muted small">Producto terminado listo para entrega</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">Información Útil</h5>
                    </div>
                    <div class="card-body">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary mr-2"></i>
                                Verifique todos los materiales antes de iniciar la producción.
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary mr-2"></i>
                                Establezca una fecha realista para la finalización.
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary mr-2"></i>
                                Incluya instrucciones específicas en los detalles de producción.
                            </li>
                            <li class="list-group-item">
                                <i class="fas fa-info-circle text-primary mr-2"></i>
                                El responsable de producción debe supervisar todo el proceso.
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Habilitar botón de iniciar producción solo cuando todos los materiales están verificados
            const materialChecks = document.querySelectorAll('.material-check');
            const btnIniciarProduccion = document.getElementById('btn-iniciar-produccion');
            
            function verificarChecks() {
                let todosMarcados = true;
                materialChecks.forEach(check => {
                    if (!check.checked) {
                        todosMarcados = false;
                    }
                });
                
                btnIniciarProduccion.disabled = !todosMarcados;
            }
            
            materialChecks.forEach(check => {
                check.addEventListener('change', verificarChecks);
            });
            
            // Calcular fecha estimada por defecto basada en tiempo de entrega
            const tiempoEntrega = '<?php echo $orden['tiempo_entrega']; ?>';
            const fechaEstimadaInput = document.getElementById('fecha_estimada_completado');
            
            let diasEstimados = 7; // Valor por defecto: 1 semana
            
            if (tiempoEntrega.includes('día')) {
                const match = tiempoEntrega.match(/(\d+)/);
                if (match) {
                    diasEstimados = parseInt(match[1]);
                }
            } else if (tiempoEntrega.includes('semana')) {
                const match = tiempoEntrega.match(/(\d+)/);
                if (match) {
                    diasEstimados = parseInt(match[1]) * 7;
                }
            } else if (tiempoEntrega === 'Inmediato') {
                diasEstimados = 3; // 3 días para producción inmediata
            }
            
            const fechaEstimada = new Date();
            fechaEstimada.setDate(fechaEstimada.getDate() + diasEstimados);
            
            // Formatear fecha yyyy-mm-dd
            const year = fechaEstimada.getFullYear();
            const month = String(fechaEstimada.getMonth() + 1).padStart(2, '0');
            const day = String(fechaEstimada.getDate()).padStart(2, '0');
            
            fechaEstimadaInput.value = `${year}-${month}-${day}`;
        });
    </script>
    
    <style>
    /* Estilos para las etapas de producción */
    .timeline-steps {
        position: relative;
        padding: 0 0 0 40px;
    }
    
    .timeline-step {
        position: relative;
        padding-bottom: 30px;
    }
    
    .timeline-step:before {
        content: '';
        position: absolute;
        left: -25px;
        top: 30px;
        bottom: 0;
        width: 2px;
        background-color: #e9ecef;
    }
    
    .timeline-step:last-child:before {
        display: none;
    }
    
    .timeline-step-marker {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        background-color: #e9ecef;
        color: #6c757d;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        position: absolute;
        left: -40px;
        top: 0;
    }
    
    .timeline-step.active .timeline-step-marker {
        background-color: #007bff;
        color: white;
    }
    
    .timeline-step-content {
        padding-bottom: 10px;
    }
    
    .timeline-step.active .timeline-step-content h6 {
        color: #007bff;
        font-weight: bold;
    }
    </style>
    
<?php
    require_once 'includes/footer.php';
    exit;
}