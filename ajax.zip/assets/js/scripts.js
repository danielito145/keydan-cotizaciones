// Scripts generales para el sistema de cotizaciones

// Inicializar tooltips de Bootstrap
$(function () {
    $('[data-toggle="tooltip"]').tooltip();
});

// Confirmar eliminación
function confirmarEliminar(mensaje, url) {
    if (confirm(mensaje)) {
        window.location.href = url;
    }
    return false;
}

// Funciones específicas para cotizaciones
function calcularSubtotal(precio, cantidad) {
    return parseFloat(precio) * parseInt(cantidad);
}

function actualizarTotal() {
    let total = 0;
    $('.subtotal').each(function() {
        total += parseFloat($(this).text() || 0);
    });
    $('#total').text(total.toFixed(2));
}