<?php
// Configuración de la base de datos
$host = 'localhost'; // Generalmente 'localhost'
$db_name = 'mar27ked_cotizaciones'; // El nombre de tu base de datos
$username = 'mar27ked_cotiz'; // El usuario que creaste
$password = 'Keyd@n145'; // La contraseña que estableciste

// Establecer conexión
try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    // Configurar el modo de error PDO a excepción
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Establecer el juego de caracteres
    $conn->exec("SET NAMES utf8");
} catch(PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
    die();
}
?>