<?php
/**
 * ajax/get_orden_detalles.php
 * Proporciona los detalles de una orden de venta en formato HTML para ser mostrados mediante AJAX
 */

// Incluir solo configuración de base de datos
require_once '../config/db.php';

// Verificar si se proporcionó un ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo '<p class="text-danger">Error: ID de orden no proporcionado</p>';
    exit;
}

$id_orden = $_GET['id'];

try {
    // Obtener datos de la orden
    $stmt = $conn->prepare("SELECT o.*, cl.razon_social as cliente 
                           FROM ordenes_venta o 
                           JOIN clientes cl ON o.id_cliente = cl.id_cliente 
                           WHERE o.id_orden = :id");
    $stmt->bindParam(':id', $id_orden);
    $stmt->execute();
    
    if ($stmt->rowCount() === 0) {
        echo '<p class="text-danger">Error: Orden no encontrada</p>';
        exit;
    }
    
    $orden = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Obtener detalles de la orden
    $stmt = $conn->prepare("SELECT od.*, m.nombre as material 
                           FROM orden_detalles od 
                           JOIN materiales m ON od.id_material = m.id_material 
                           WHERE od.id_orden = :id");
    $stmt->bindParam(':id', $id_orden);
    $stmt->execute();
    $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Generar HTML con los detalles
    ob_start();
?>
    <div class="card border-0 mb-0">
        <div class="card-body p-0">
            <h6 class="border-bottom pb-2 mb-3">Información de la Orden</h6>
            <div class="row mb-3">
                <div class="col-md-6">
                    <p class="mb-1"><strong>Código:</strong> <?php echo $orden['codigo']; ?></p>
                    <p class="mb-1"><strong>Cliente:</strong> <?php echo $orden['cliente']; ?></p>
                </div>
                <div class="col-md-6">
                    <p class="mb-1"><strong>Fecha:</strong> <?php echo date('d/m/Y', strtotime($orden['fecha_emision'])); ?></p>
                    <p class="mb-1"><strong>Estado:</strong> 
                        <span class="badge 
                            <?php 
                            switch($orden['estado']) {
                                case 'pendiente': echo 'badge-warning'; break;
                                case 'en_produccion': echo 'badge-info'; break;
                                case 'completada': echo 'badge-success'; break;
                                case 'cancelada': echo 'badge-danger'; break;
                                default: echo 'badge-secondary';
                            }
                            ?>">
                            <?php echo ucfirst(str_replace('_', ' ', $orden['estado'])); ?>
                        </span>
                    </p>
                </div>
            </div>
            
            <h6 class="border-bottom pb-2 mb-3">Productos a Producir</h6>
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th>Descripción</th>
                            <th>Material</th>
                            <th>Medidas</th>
                            <th>Cantidad</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($detalles) > 0): ?>
                            <?php foreach($detalles as $detalle): ?>
                                <tr>
                                    <td><?php echo $detalle['descripcion']; ?></td>
                                    <td><?php echo $detalle['material']; ?></td>
                                    <td>
                                        <?php 
                                        // Si hay espesor, usarlo en lugar del micraje
                                        if (!empty($detalle['espesor'])) {
                                            echo $detalle['ancho'] . ' x ' . $detalle['largo'] . ' x ' . $detalle['espesor'];
                                        } else {
                                            echo $detalle['ancho'] . ' x ' . $detalle['largo'] . ' x ' . $detalle['micraje'] . ' mic';
                                        }
                                        
                                        if ($detalle['fuelle'] > 0) {
                                            echo ' (Fuelle: ' . $detalle['fuelle'] . ')';
                                        }
                                        ?>
                                    </td>
                                    <td class="text-right"><?php echo number_format($detalle['cantidad']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">No hay productos en esta orden</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="alert alert-info mt-3 mb-0">
                <i class="fas fa-info-circle"></i> 
                Esta orden tiene <strong><?php echo count($detalles); ?></strong> productos para producir. 
                Al crear la orden de producción, se generarán automáticamente todas las etapas necesarias (corte, sellado, control de calidad, empaque).
            </div>
        </div>
    </div>
<?php
    $html = ob_get_clean();
    echo $html;
    
} catch(PDOException $e) {
    echo '<p class="text-danger">Error al obtener los detalles: ' . $e->getMessage() . '</p>';
}